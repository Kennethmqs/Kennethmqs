<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />

    <title>PMS|Login</title>

      <link rel="stylesheet"  type="image/png" href="<?php echo base_url(); ?>assets/icon.png">
    <!-- Bootstrap core CSS -->
      <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet"  href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css">
      <link rel="stylesheet"  href="<?php echo base_url(); ?>/assets/js/bootstrap.min.js">
      <link rel="stylesheet"  href="<?php echo base_url(); ?>/assets/css/style.css">
  </head>

  <body style="background-image: url( <?php echo base_url(); ?>assets/images/Login-register.jpg);">
    <nav class="navbar navbar-default" style="background-color: #2e6da4">
      <div class="container">
        
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li  style="align-self: center;"><a href="#">Pharmacy Management System</a></li>
          </ul>
          
        </div>
        <!--/.nav-collapse -->
      </div>
    </nav>
    <!--/.nav End -->

    <header id="header" style="background-color: skyblue">
      <div class="container">
        <div class="col-md-10">
          <h1 class="text-center">
            <span class="glyphicon" aria-hidden="true"></span>
           <small style=" color: white;">password reset</small>
          </h1>
             <?php if(isset($message)) { ?>
        <p><?php echo $message; ?></p>
    <?php } ?>
        </div>
       </div>
      </div>
    </header>

 
    <!-- /.container -->
   <section id="main">
       <div class="row" >
           <div class="col-md-4 col-md-offset-4">
               <form method="post" class="well" action="<?php echo site_url('ShowForm/send_reset_link'); ?>" style="background-color: transparent;">
                    
                      
                    <div class="form-group">
                      <label for="email">enter your email</label>
                     
                       <input type="email" name="email" required>
                        
                    </div>
                    <!--<button type="submit" class="btn btn-default">Submit</button>-->
                   <button type="submit"   class="btn btn-success">Reset Link</button>
                  
                
                  </form>
           </div>
       </div>
   </section>
    
    <!-- /.Footer -->
    <footer id="footer" class="navbar navbar-fixed-bottom" style="background-color: #2e6da4">
  <p>&copy;<?php echo date('Y')?>  </p>
    </footer>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="assets/js/bootstrap.min.js"></script>
  </body>
</html>