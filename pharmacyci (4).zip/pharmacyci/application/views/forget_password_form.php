<!DOCTYPE html>
<html>
<head>
    <title>Forget Password</title>
</head>
<body>
    <!-- Forget Password Form -->
    <form action="<?php echo base_url('ForgetPasswordController'); ?>" method="post">
        <label for="email">Enter your email:</label>
        <input type="email" id="email" name="email" required>
        <button type="submit">Submit</button>
    </form>
</body>
</html>