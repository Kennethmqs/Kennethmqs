<?php


class Main_model extends CI_Model
{
  function can_login($username,$password){
  	$this->db->where('username',$username);
	  $this->db->where('password',$password);
	  $query = $this->db->get('admin');
	  //SELECT * FROM users WHERE username = '$username' AND password = '$password'
	  if($query->num_rows()>0){
	  	return true;
	  }else{
	  	return false;
	  }
  }
	function staff_can_login($username,$password,$email){
		$this->db->where('username',$username);
		$this->db->where('password',$password);
		 $this->db->where('email',$email);
		$query = $this->db->get('staff');
		//SELECT * FROM users WHERE username = '$username' AND password = '$password'
		if($query->num_rows()>0){
			return true;
		}else{
			return false;
		}
	}
	  public function get_staff_by_email($email) {
        // Retrieve staff information based on the provided email
        $query = $this->db->get_where('staff', array('email' => $email));
        return $query->row();
    }
}
