<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ForgetPasswordController extends CI_Controller {

    public function index() {
        // Include the database configuration and connection
        $this->load->database();
        $this->load->model('StaffModel');
        $this->processForm();
        $this->load->view('forget_password_form');
    }

    private function processForm() {
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $email = $this->input->post("email");

            // Validate email (you can add more validation if needed)

            // Check if the email exists in the database
            $staff = $this->StaffModel->getStaffByEmail($email);

            if ($staff) {
                // Email exists in the database
                // You can implement the password reset functionality here and send a reset link to the user's email.
                // For simplicity, let's just echo a success message.
                echo "Password reset link sent to your email!";
            } else {
                // Email not found in the database
                // You can display an error message or redirect back to the forget password form.
                echo "Email not found!";
            }
        }
    }
}